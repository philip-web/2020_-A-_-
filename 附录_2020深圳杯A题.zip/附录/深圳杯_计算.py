import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pyecharts.charts as pc
import random
from scipy import optimize
# import cvxpy as cp
random.seed(1)

# data = pd.read_csv("E:/深圳杯/数据/深圳人口数据.csv", encoding="gbk")
def death_rate():
    data = pd.read_csv("E:/深圳杯/数据/深圳人口数据.csv", encoding="utf-8")
    d1=data["年末常住人口数（万人）（增长率，平均值与标准偏差（5年、7年、10年））"]
    d11=[]
    d11.append(0)
    for i in range(1,len(d1)):
        d11.append((d1[i]-d1[i-1])/d1[i-1])
    data.insert(3,"年末常住人口数（万人）（环比增长率）",d11,allow_duplicates=True)
    data.to_csv("E:/深圳杯/数据/深圳人口数据.csv",index=False)
#
# death_rate()
def economic():
    data=pd.read_csv("E:/深圳杯/数据/深圳经济数据.csv",encoding="utf8")
    d1=data["年平均工资（元）"]
    d11 = []
    d11.append(0)
    for i in range(1, len(d1)):
        d11.append((d1[i] - d1[i - 1]) / d1[i - 1])
    data.insert(2, "环比(每年增长比率)", d11, allow_duplicates=True)
    data.to_csv("E:/深圳杯/数据/深圳经济数据.csv", index=False)
# economic()

def death_5():
    d_5= data["死亡率（‰）"]
    d_5_mean=[]
    d_5_st = []
    for i in range(len(d_5)):
        if (i+1)%5==0:
            d5=np.array(d_5[(i-4):(i+1)])
            d_5_mean.append(d5.mean())
            d_5_st.append(d5.std())
    for i in range(len(d_5)-len(d_5_mean)):
        d_5_mean.append(0)
    for i in range(len(d_5)-len(d_5_st)):
        d_5_st.append(0)
    data.insert(6, "5年均值", d_5_mean, allow_duplicates=True)
    data.insert(7, "5年标准差", d_5_st, allow_duplicates=True)
    data.to_csv("E:/深圳杯/数据/深圳人口数据.csv", index=False)
    print(data)
# death_5()

def plot_rk():
    dr=data["年末常住人口数（万人）（增长率，平均值与标准偏差（5年、7年、10年））"]
    year=data["年份"]
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    sns.barplot(year,dr)
    plt.ylabel("常住人口数(万人)",fontsize=12)
    plt.xlabel("年份",fontsize=12)
    plt.title("1979-2019年深圳市常住人口数",fontsize=15)
    plt.xticks(rotation=90)
    for a, b in zip(range(len(year)), dr):
        plt.text(a, b+9, b, ha='center', va='bottom',rotation=-90)
    plt.show()

# plot_rk()

def tuiduan_10(people):   #第一小问整体
    data=pd.read_csv("E:/深圳杯/数据/深圳市分年龄人口数和死亡率.csv",encoding="gbk",index_col=0)
    data_rate=data["占比"][12:19]
    d=pd.DataFrame(index=["60-64","65-69","70-74","75-79","80-84","85-89","90以上","总计"])
    for i in range(33,len(people)+33):
        data_per_stage=[people[i]*j*10**4 for j in data_rate]
        data_per_stage.append(sum(data_per_stage))
        d[str(2012+i-33)]=data_per_stage
    print(d)
# p=data["年末常住人口数（万人）（增长率，平均值与标准偏差（5年、7年、10年））"][33:39]
# tuiduan_10(p)

def old():
    data=pd.read_excel("E:/深圳杯/数据/12-17人口结构.xls",encoding="gbk",index_col=0)
    print(data.index)
    for i in range(len(data)):
        data1=data.iloc[i,:].values.astype(float)
        plt.subplot(3,3,i+1)
        plt.rcParams['font.sans-serif'] = ['SimHei']
        plt.rcParams['axes.unicode_minus'] = False
        if i <= 5:
            plt.plot(range(len(data1)),data1)
            plt.title(data.index[i], color='b')
        else:
            x=['2012年','2013年','2014年','2015年','2016年','2017年']
            plt.plot(x,data1)
            plt.xticks(rotation=30,fontsize=10)
            plt.title(data.index[i],color='b')
    plt.show()
# old()

def old_total():
    data = [433333, 493218, 555011, 630986, 709001, 784268]
    # x = ['2012年', '2013年', '2014年', '2015年', '2016年', '2017年']
    # plt.rcParams['font.sans-serif'] = ['SimHei']
    # plt.rcParams['axes.unicode_minus'] = False
    # sns.plot(x,data,color="orange")
    # plt.title("2012-2017年60岁以上总人口数据")
    # plt.show()
    # zl=[]
    # for i in range(1,len(data)):
    #     zl.append(round((data[i]-data[i-1])/data[i-1],4))
    # zl_m=round(sum(zl)/(len(zl)),4)
    # a18_19=[784268*zl_m ,784268*zl_m**2]
    # print(a18_19)

    # line = pc.Line()
    # x = ['2012年', '2013年', '2014年', '2015年', '2016年', '2017年']
    # line.add_xaxis(x)
    # line.add_yaxis("60岁以上总人口数",[433333, 493218, 555011, 630986, 709001, 784268])
    # line.page_title="2012-2017年60岁以上总人口数据"
    # line.render("E:/深圳杯/数据/60以上.html")
    d_rate=[0.055060544,0.430888737,0.51405072]
    labels=["<15", "15-59", ">59"]
    plt.pie(d_rate, autopct = '%3.4f%%',labels=labels)
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.title("2010年三个层级死亡率占比图")
    plt.legend(["<15","15-59",">59"],loc='upper right')
    plt.show()


# old_total()
def rkjg():
    d_rk=pd.read_csv("E:/深圳杯/数据/人口结构.csv",encoding="gbk")
    d1=d_rk["非户籍常住人口数量"]
    d2=d_rk["户籍人口数量"]
    d_rk["常住人口数"]=d1+d2
    d_cz=d_rk["常住人口数"]
    d_rk["年龄"]=d_rk["年龄"].replace(random.randint(80,99),999)
    print("总人口数",sum(d_cz))
    d_y = d_rk["年龄"]
    a=[]
    for i in range(21):
        a.append([])
    for j in range(len(d_cz)):
        if d_y[j]<100:
            a[int(d_y[j])//5].append(d_cz[j])
        else:
            a[-1].append(d_cz[j])
    b=[]
    for i in a:
        b.append(sum(i))
    d=pd.DataFrame({"年龄段":["0-4","5-9","10-14","15-19","20-24","25-29","30-34","35-39","40-44","45-49",\
                            "50-54","55-59","60-64","65-69","70-74","75-79","80-84","85-89","90-94","95-99",">=100"],"人数":b})
    d.to_csv("E:/深圳杯/数据/人口结构1.csv",index=False)
# rkjg()




def first(total):
    #死亡率来于深圳市整体数据2011-2018年死亡率取随机因子
    death_rate=[0.0011,0.00138,0.00107,0.00241,0.00128,0.00134,0.00153,0.00129]
    d_mean=sum(death_rate)/len(death_rate)
    d_std=0.0004245
    d_15_rate=[d_mean+random.uniform(-d_std,d_std) for i in range(0,15)]

    d_stage=pd.read_csv("E:/深圳杯/数据/人口结构2.csv",encoding="gbk")["人数"]
    rk_rate=[i/sum(d_stage) for i in d_stage ]
    rate_60=0.072   #老年人口占比是2012-2017年老年人口占比
    peo_60=total*rate_60
    peo_45_60=[rk_rate[9]*total,rk_rate[10]*total,rk_rate[11]*total]

    #预测五年
    d_rate_60=d_15_rate[random.randint(0,15)]            #60岁以上的死亡率
    d_rate_55=d_15_rate[random.randint(0,15)]
    peo_60_now=peo_60*(1-d_rate_60)
    peo_55_59=peo_45_60[2]*(1-d_rate_55)                              #55-59进的人数
    peo_60_5=peo_60_now+peo_55_59
    print("五年之后的60以上人数",round(peo_60_5,4))

    #预测十年
    d_rate_60 = d_15_rate[random.randint(0,15)]  # 60岁以上的死亡率
    d_rate_55 = d_15_rate[random.randint(0,15)]
    d_rate_50=d_15_rate[random.randint(0,15)]
    peo_60_now = peo_60 * (1 - d_rate_60)*(1 - d_rate_60)
    peo_55_59 = peo_45_60[2] * (1 - d_rate_55)*(1 - d_rate_60)  # 55-59进的人数
    peo_50_55=peo_45_60[1]*(1-d_rate_50)*(1-d_rate_55)
    peo_60_10 = peo_60_now + peo_55_59+peo_50_55
    print("十年之后的60以上人数", round(peo_60_10,4))

    #预测十五年
    d_rate_60 = d_15_rate[random.randint(0,15)]  # 60岁以上的死亡率
    d_rate_55 = d_15_rate[random.randint(0,15)]
    d_rate_50 = d_15_rate[random.randint(0,15)]
    d_rate_45=  d_15_rate[random.randint(0,15)]
    peo_60_now = peo_60 * (1 - d_rate_60) * (1 - d_rate_60)*(1 - d_rate_60)
    peo_55_59 = peo_45_60[2] * (1 - d_rate_55) * (1 - d_rate_60)*(1 - d_rate_60)  # 55-59进的人数
    peo_50_55 = peo_45_60[1] * (1 - d_rate_50) * (1 - d_rate_55)*(1 - d_rate_60)
    peo_45_49=peo_45_60[0] * (1 - d_rate_45) * (1 - d_rate_50)*(1-d_rate_55)*(1 - d_rate_60)
    peo_60_15 = peo_60_now + peo_55_59 + peo_50_55+peo_45_49
    print("十五年之后的60以上人数", round(peo_60_15,4))
    return [round(peo_60_5,4),round(peo_60_10,4),round(peo_60_15,4)]


# print(first(1343.88))

def chuang_num():
    f=first(1302.66)
    peo=66774
    chuangnum=1694777*0.808
    rz_rate=round(peo/chuangnum,4)    #养老院入住率
    rz_epo=[round(rz_rate*i*10**4) for i in f]
    print(rz_epo)          #入住人数
# chuang_num()

def hospital(total_peo):
    # per_year_tpe=[8638.0,9112.1,8852.6,8900.6,9598.3,9959.8,9985.9]  #每年接诊人数
    cy_peo=[105.0687,109.2137,119.3257,123.8808,138.1748,150.2949,161.8872]   #出院人次
    tp=[1054.74,1062.89,1077.89,1137.87,1190.84,1252.83,1302.66]       #每年总人数a_15[random.randint(0,15)
    a=[round(cy_peo[i]/tp[i],4) for i in range(len(tp))]
    print(a)
    std_a=0.008949648
    a_15=[sum(a)/len(a)+random.uniform(0,std_a) for i in range(15)]
    cwei_shu=int((a_15[random.randint(0,15)])*total_peo*10**4*7.8/299)+int(total_peo*10*0.5)
    print("2019年实际预测需要床位数",int(cwei_shu))
    per_thousand_cwei_shu=cwei_shu/(total_peo*10)
    print("2019年每千人床位数",round(per_thousand_cwei_shu,1))
    per_t_cws=6
    rks=total_peo*10**4/1000*per_t_cws
    print("2019年按标准需要有多少床位",int(rks))
    per_t_cws_jp =12
    rks_jp = total_peo * 10 ** 4 / 1000 * per_t_cws_jp
    print("2019年按日本标准需要有多少床位", int(rks_jp))
    #预测十五年床位数
    rk_peo=[1350.3579,1387.3262,1431.9187,1480.9325,1533.0054,1587.804,1646.6515,1710.599,1780.6971,1857.8385, \
            1941.4287,2032.242,2131.2522,2238.4001,2357.6655]  #未来十五年每年人口总数
    rd=random.randint(0,15)
    cws_forcast_format=[int((a_15[rd])*i*10**4*7.8/299)+int(total_peo*10*0.5) for i in rk_peo]
    print("按公式计算，需要床位数",cws_forcast_format)
    #按千人比例计算
    cws_per_th = [int(i*10**4/1000*per_t_cws) for i in rk_peo]
    print("按千人标准计算,需要床位数",cws_per_th)

    #按日本比例
    cws_per_th_jp = [int(i * 10 ** 4 / 1000 * per_t_cws_jp) for i in rk_peo]
    print("按日本标准计算,需要床位数", cws_per_th_jp)

    #2019年开始,未来5年、10年、15年需要增加床位数
    cws_5_future=cws_forcast_format[4]-47366
    cws_10_future = cws_forcast_format[9]-47366
    cws_15_future = cws_forcast_format[14]-47366
    print("未来五年需要增加医院床位数",cws_5_future)
    print("未来十年需要增加医院床位数",cws_10_future)
    print("未来十五年需要增加医院床位数",cws_15_future)

    #预测医院数
    # data = pd.read_csv("E:/深圳杯/数据/深圳医护数据.csv", encoding="gbk")  # 深圳市医护数据床位数2002-2018
    # d_ys = data["医院床位数"][0:-1]
    # yyshu = data["医院数"][0:-1]  # 深圳市全市医院数2002-2018
    # print(d_ys[])
    # per_h_cs = round((d_ys[len(d_ys) - 1] - d_ys[0]) / (yyshu[len(yyshu) - 1] - yyshu[0]))
    # print("2002-2018年每增加一个医院数平均增加多少床位", per_h_cs)

    # 医院数,直接按照三甲医院描述
    # add_5 = round(cws_5_future/ per_h_cs)
    # add_10 = round(cws_10_future / per_h_cs)
    # add_15 = round(cws_15_future/ per_h_cs)
    # print("未来5年需要增加医院数", add_5)
    # print("未来10年需要增加医院数", add_10)
    # print("未来15年需要增加医院数", add_15)

    #医护人员数
    cws_5_future=cws_forcast_format[4]   #5年后需要的总床位数
    cws_10_future = cws_forcast_format[9]
    cws_15_future = cws_forcast_format[14]
    future_5_doctor=cws_5_future/1.389207613   #按美国床位数/医生数比率，5年后的医护人员数
    future_10_doctor = cws_10_future / 1.389207613  # 按美国比率，5年后的医护人员数
    future_15_doctor = cws_15_future / 1.389207613  # 按美国比率，5年后的医护人员数
    print("按美国比率5年后需要的综合医院执业医师数",future_5_doctor)
    print("按美国比率10年后需要的综合医院执业医师数", future_10_doctor)
    print("按美国比率15年后需要的综合医院执业医师数", future_15_doctor)

    print("按美国比率5年后需要增加的综合医院执业医师数", future_5_doctor - 21543)
    print("按美国比率10年后需要增加的综合医院执业医师数", future_10_doctor - 21543)
    print("按美国比率15年后需要增加的综合医院执业医师数", future_15_doctor - 21543)

    #未来5年、10年、15年的卫生技术人员数量，由以上医生数/深圳市医生数占全市卫生技术人员数量得到
    future_5_hworker=future_5_doctor/0.211066839
    future_10_hworker = future_10_doctor / 0.211066839
    future_15_hworker = future_15_doctor / 0.211066839
    print("按美国比率5年后需要的卫生工作人员数", future_5_hworker)
    print("按美国比率10年后需要的卫生工作人员数", future_10_hworker)
    print("按美国比率15年后需要的卫生工作人员数", future_15_hworker)

    #需增加
    print("按美国比率5年后需要的卫生工作人员数", future_5_hworker-103012)
    print("按美国比率10年后需要的卫生工作人员数", future_10_hworker-103012)
    print("按美国比率15年后需要的卫生工作人员数", future_15_hworker-103012)

    #按照深圳现今比例
    # 医护人员数
    future_5_doctor_sz = cws_5_future / 1.5884045861764842  # 按美国床位数/医生数比率，5年后的医护人员数
    future_10_doctor_sz = cws_10_future /1.5884045861764842  # 按美国比率，5年后的医护人员数
    future_15_doctor_sz = cws_15_future /1.5884045861764842 # 按美国比率，5年后的医护人员数
    print("按深圳现今比率5年后需要的综合医院执业医师数", future_5_doctor_sz)
    print("按深圳现今比率10年后需要的综合医院执业医师数", future_10_doctor_sz)
    print("按深圳现今比率15年后需要的综合医院执业医师数", future_15_doctor_sz)

    print("按深圳现今比率5年后需要增加的综合医院执业医师数", future_5_doctor_sz - 21543)
    print("按深圳现今比率10年后需要增加的综合医院执业医师数", future_10_doctor_sz- 21543)
    print("按深圳现今比率15年后需要增加的综合医院执业医师数", future_15_doctor_sz - 21543)

    # 未来5年、10年、15年的卫生技术人员数量，由以上医生数/深圳市医生数占全市卫生技术人员数量得到
    future_5_hworker_sz = future_5_doctor_sz / 0.211066839
    future_10_hworker_sz = future_10_doctor_sz / 0.211066839
    future_15_hworker_sz = future_15_doctor_sz / 0.211066839
    print("按深圳现今比率5年后需要的卫生工作人员数", future_5_hworker_sz)
    print("按深圳现今比率10年后需要的卫生工作人员数", future_10_hworker_sz)
    print("按深圳现今比率15年后需要的卫生工作人员数", future_15_hworker_sz)

    # 需增加
    print("按深圳现今比率5年后需要增加的卫生工作人员数", future_5_hworker_sz- 103012)
    print("按深圳现今比率10年后需要增加的卫生工作人员数", future_10_hworker_sz - 103012)
    print("按深圳现今比率15年后需要增加的卫生工作人员数", future_15_hworker_sz - 103012)

    # return [cws_5_future,cws_10_future,cws_15_future]
# hospital(1343.88)

def G_1_1():     #灰色预测模型
    data=pd.read_csv("E:/深圳杯/数据/深圳医护数据.csv", encoding="gbk") #深圳市医护数据床位数2002-2018
    d_ys=data["医院床位数"][0:-1]
    print(d_ys)
    x1=[sum(d_ys[0:i]) for i in range(1,len(d_ys))]
    Y=d_ys[1:len(d_ys)]
    print(Y)
    B1=[(-1/2)*(x1[i]+x1[i-1]) for i in range(len(x1))]
    B2=[1 for i in range(len(Y))]
    B=np.array([B1,B2])
    a_u=np.dot(np.dot(np.linalg.inv(np.dot(B,B.T)),B),Y)
    #模型
    mx_forcast=[(d_ys[0]-a_u[1]/a_u[0])*np.exp(-a_u[0]*t)+a_u[1]/a_u[0] for t in d_ys]
    print(mx_forcast)

# G_1_1()

def old_house():  #养老院数量
    peo=[127.5196*10**4*0.020380776,187.4633*10**4*0.020380776,293.4273*10**4*0.020380776]   #按美国60以上老年人口入住养老院比率为0.020380776
    print(peo)
    print("5年后需要养老院床位数",peo[0])
    print("10年后需要养老院床位数", peo[1])
    print("15年后需要养老院床位数", peo[2])
    lei_1=[3/8,1/8,4/8]    #第一类的按公办、公建民营、民办三种排列
    lei_2=[3/10,2/10,5/10]
    lei_3=[13/28,8/28,7/28]

    # 按六种比率配置
    #五年后的人数分配
    for j in range(len(peo)):
        print(str((j+1)*5)+"年后的养老院床位数分配")
        peo_1=[peo[j]*i for i in lei_1]   #第一类的人数分配
        print("全按第一类配置",peo_1)
        peo_2=[peo[j]*i for i in lei_2]
        print("全按第二类配置", peo_2)
        peo_3 = [peo[j] * i for i in lei_3]
        print("全按第三类配置", peo_3)
        #第四类
        rate=[4/24*peo[j],5/24*peo[j],15/24*peo[j]]   #4:5:15比例
        peo_41=[rate[0]*i for i in lei_1];peo_42=[rate[1]*i for i in lei_2];peo_43=[rate[2]*i for i in lei_3]
        peo_4=[(peo_41[0]+peo_42[0]+peo_43[0]),peo_41[1]+peo_42[1]+peo_43[1],peo_41[2]+peo_42[2]+peo_43[2]]   #公办、公建民营、民办三种排列
        print("按第四类配置", peo_4)
        #第五类
        rate = [4/9* peo[j], 5/9*peo[j],0*peo[j]]  # 4:5:0比例
        peo_51 = [rate[0] * i for i in lei_1];peo_52 = [rate[1] * i for i in lei_2];peo_53 = [rate[2] * i for i in lei_3]
        peo_5 = [peo_51[0]+peo_52[0]+peo_53[0],peo_51[1]+peo_52[1]+peo_53[1],peo_51[2]+peo_52[2]+peo_53[2]]  # 公办、公建民营、民办三种排列
        print("按第五类配置",peo_5)
        #第六类
        rate = [1/3* peo[j],1/3* peo[j], 1/3* peo[j]]  # 4:5:0比例
        peo_61 = [rate[0] * i for i in lei_1];peo_62 = [rate[1] * i for i in lei_2];peo_63 = [rate[2] * i for i in lei_3]
        peo_6 = [peo_61[0]+peo_62[0]+peo_63[0],peo_61[1]+peo_62[1]+peo_63[1],peo_61[2]+peo_62[2]+peo_63[2]]  # 公办、公建民营、民办三种排列
        print("按第六类配置", peo_6)
        print("\n"*2)
    #养老院工作人员数,按床位数/医生数计算
    old_worker_am=[i/1.245271387 for i in peo]   #美国
    old_worker_jp= [i*1.109 for i in peo]  #日本
    old_worker_shen_high=[i/15 for i in peo]
    old_worker_shen_low=[i/2.09 for i in peo]
    old_worker_shen_mi=[i/4.2 for i in peo]
    old_worker_shen_16 = [i / 16 for i in peo]
    print("按美国床位数/医生的比率需要的工作人员数",old_worker_am)   #按美国算
    print("按日本床位数/医生的比率需要的工作人员数", old_worker_jp)  # 按美国算
    print("按深圳现有的15/1算床位数/医生的比率需要的工作人员数", old_worker_shen_high)  # 按深圳16/1算
    print("按深圳现有的2/1算床位数/医生的比率需要的工作人员数", old_worker_shen_low)  # 按深圳2/1算
    print("按深圳现有的4/1算床位数/医生的比率需要的工作人员数", old_worker_shen_mi)  # 按深圳4/1算
    print("按深圳现有的16/1算床位数/医生的比率需要的工作人员数", old_worker_shen_16)  # 按深圳4/1算

# old_house()

def mbgh():   #目标规划
    # d_mb=pd.read_csv("人口比例.csv",encoding="gbk")
    # d_1=pd.DataFrame()
    # d_1["行政区"]=d_mb["行政区"]
    # d_1["人口占比1"]=d_mb["人口占比1"]
    # d_1["卫生技术人员占比"]=d_mb["卫生技术人员占比"]
    # d_1["累计百分比1"] = d_mb["累计百分比1"]
    # print(d_1)
    # 确定c,A,b,Aeq,beq
    n=11
    c = np.array([10,9, 8,7,6,5,4,3,2,1,0])
    a = np.array([[1, 1, 1,1, 1, 1,1, 1, 1,1, 1]])
    b = np.array([52325])
    x = cp.Variable(n, integer=True)
    objective = cp.Maximize(cp.sum(c * x))
    constriants = [0<= x,a*x<=b]
    prob = cp.Problem(objective, constriants)
    resluts = prob.solve(solver=cp.CPLEX)

    # 输入结果
    print(prob.value)  # 目标函数的值
    print(x.value)  # 各x的值



    # # 求解
    # res =optimize.linprog(c,Aeq, beq)
    # print(res.x)
    # # g=1-(2*52325+1)/11
    # # print(g)
    # t=res.x
    # for i in t:
    #     print(i*52325)

# mbgh()

